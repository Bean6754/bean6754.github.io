<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title>Downloads</title>
    <link rel="stylesheet" type="text/css" href="../css/global.css">
  </head>
  <body>
    <h2>Downloads</h2>

    <div id="navbar">
      <a href="../index.php">C:\</a>
      <br>
    </div>

    <br><a href="../backup.zip">backup.zip</a><br>
    <a href="../backup.sh">backup.sh</a>
  </body>
</html>
