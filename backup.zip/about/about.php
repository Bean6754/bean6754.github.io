<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title>About</title>
    <link rel="stylesheet" type="text/css" href="../css/global.css">
  </head>
  <body>
    <h2>About</h2>

    <a href="../index.php">..</a><br>
    
    <p>PHP status: PHP is <span style="color:green"><?php echo "'running'" ?></span>.</p>
    <p>Server IP (requires PHP status to be 'running'): <span style="color:red"><?php echo $_SERVER['SERVER_ADDR'] . ":" . $_SERVER['SERVER_PORT']; ?></span>.</p>
  </body>
</html>
