<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title>Colors</title>
    <link rel="stylesheet" type="text/css" href="../css/global.css">
  </head>
  <body>
    <h2>ColorScheme</h2>

    <div id="navbar">
      <a href="../index.php">C:\</a>
      <br>
    </div>

    <p>Background color: [<span style="color:#333;">#333</span>]</p>
    <p>Paragraph color: [<span style="color:#CCC;">#CCC</span>]</p>
    <p>Hyperlink color: [<span style="color:#2A7EFC;">#2A7EFC</span>]</p>
    <p>Code color: [<span style="color:#00CC00;">#00CC00</span>]</p>
  </body>
</html>
