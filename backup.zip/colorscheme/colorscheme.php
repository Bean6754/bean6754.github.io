<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title>Colors</title>
    <link rel="stylesheet" type="text/css" href="../css/global.css">
  </head>
  <body>
    <h2>ColorScheme</h2>

    <a href="../index.php">..</a><br>

    <p>Background color: [<span style="background-color:#000;color:#333;">#333</span>]</p>
    <p>Header and paragraph color: [<span style="color:#CCC;">#CCC</span>]</p>
    <p>Hyperlink color: [<span style="color:#2A7EFC;">#2A7EFC</span>]</p>
    <p>Code color: [<span style="color:#00CC00;">#00CC00</span>]</p>
    <p>Pre color: [<span style="color:#00CC00;">#00CC00</span>]</p>
  </body>
</html>
