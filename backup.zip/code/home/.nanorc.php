<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="../../css/global.css">
  </head>
  <body>
    <h2>Home</h2>
    
    <a href="home.php">..</a><br>
    <pre>
include /usr/share/nano/*
    </pre>
  </body>
</html>
