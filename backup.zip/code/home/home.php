<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="../../css/global.css">
  </head>
  <body>
    <h2>Home</h2>

    <div id="navbar">
      <a href="../../index.php">C:\</a><br>
    </div>
    
    <a href="../code.php">..</a><br>
    <a href=".emacs.php">.emacs</a><br>
    <a href=".nanorc.php">.nanorc</a>
  </body>
</html>
