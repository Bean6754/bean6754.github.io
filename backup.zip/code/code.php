<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title>Code</title>
    <link rel="stylesheet" type="text/css" href="../css/global.css">
  </head>
  <body>
    <h2>Code</h2>

    <div id="navbar">
      <a href="../index.php">C:\</a>
      <br>
    </div>

    <p>To download raw copies: <code>curl -LO matthewdean.uk/code/home/.emacs ; .nanorc ; etc..</code></p>
    <a href="home/home.php">Home folder</a><br>
    <a href="windowsbatchfiles/windowsbatchfiles.php">Windows Batch Files</a><br>
  </body>
</html>
