<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title>Windows Batch Files</title>
    <link rel="stylesheet" type="text/css" href="../../css/global.css">
  </head>
  <body>
    <h2>Windows Batch Files</h2>
    
    <a href="../code.php">..</a><br>
    <a href="ntp.bat.php">ntp.bat</a><br>
  </body>
</html>
