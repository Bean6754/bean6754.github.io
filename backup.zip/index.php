<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title>Welcome!</title>
    <link rel="stylesheet" type="text/css" href="css/global.css">
  </head>
  <body>
    <h1>Home</h1>

    <div id="navbar">
      <a href="about/about.php">About</a>
      <br>
      <a href="code/code.php">Code</a>
      <br>
      <a href="colours/colours.php">Colours</a>
      <br>
      <a href="downloads/downloads.php">Downloads</a>
    </div>
    
    <p><?php echo php_uname('s') . " " . php_uname('r') . " " .  "(" . php_uname('m')  . ")" ?></p>
  </body>
</html>
