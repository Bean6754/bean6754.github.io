#!/bin/bash

# gzip.
# tar -zcvf backup.tar.gz --exclude='*.tar.gz' .

# Zip.
zip -r backup.zip . -x *.zip
