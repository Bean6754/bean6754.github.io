function help1() {
  alert("Hey");
}

function help2() {
  alert("Hey2");
}
